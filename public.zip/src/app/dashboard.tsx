import { useAuthGuard } from './middleware/requireAuth';

const Dashboard = () => {
    useAuthGuard();

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold">Premium Dashboard</h1>
            <p>Welcome to the premium dashboard, accessible only for paid users.</p>
        </div>
    );
};

export default Dashboard;
