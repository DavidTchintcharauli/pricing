import { loadStripe } from "@stripe/stripe-js";

// const stripePromise = loadStripe

export default function Pricing() {
    // const handleSubscribe = async (priceId: string) => {
    //     const stripe = await stripePromise;
    //     const response = await fetch('/api/checkout', {
    //         method: 'POST',
    //         headers: {
    //             'Content-Type': 'application/json',
    //         },
    //         body: JSON.stringify({ priceId }),
    //     });
    //     const data = await response.json();
    //     stripe?.redirectToCheckout({ sessionId: data.sessionId });
    // };
 
    return (
        <div>
            <h1>Pricing</h1>
            <div>
                <h2>Free Plan</h2>
                <p>Access to basic features</p>
                <button disabled>Current Plan</button>
            </div>
            <div>
                <h2>Premium Plan</h2>
                <p>Access to all features</p>
                {/* <button onClick={() => handleSubscribe(process.env.PREMIUM_PLAN_ID!)}>
                    Subscribe
                </button> */}
            </div>
        </div>
    );
 };