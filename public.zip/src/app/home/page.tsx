export default function home() {
    return(
        <div>
            home
        </div>
    )
}